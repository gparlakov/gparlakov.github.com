﻿/// <reference path="requestMaker.js" />
/// <reference path="class.js" />
/// <reference path="q.js" />
/// <reference path="jquery-2.0.2.js" />

var BullsAndCows = BullsAndCows || {};

BullsAndCows.persister = (function () {

    var MainPersister = Class.create({
        init: function (url) {
            this.serviceUrl = url;
            this.userPersister = new UserPersister(url);
            this.userPersister.loadUserData();
        },
        userIsLoggedIn: function () {
            username = this.userPersister.username;
            sessionKey = this.userPersister.sessionKey;
            if (username && sessionKey &&
                username !== 'undefined' && sessionKey !== 'undefined') {
                return true;
            }

            return false;
        }
    });

    var UserPersister = Class.create({       

        init: function (url) {
            this.userUrl = url + "user/";
        },

        registerUser: function (name, nickName, password) {
            var that = this;

            var authCode = CryptoJS.SHA1(password).toString();

            var dataToSend = {
                "username": name,
                "nickname": nickName,
                "authCode": authCode
            }

            return requester.httpPost(that.userUrl + 'register', dataToSend)
                .then(function (data) {
                    that.sessionKey = data.sessionKey;
                    that.nickname = data.nickname;
                }).fail();
        },

        login: function (username, password) {
            var that = this;           
            var authCode = CryptoJS.SHA1(password).toString();

            var dataToSend = {
                username: username,
                authCode: authCode
            }

            return requester.httpPost(that.userUrl + 'login', dataToSend)
            .then(function (data) {
                that.saveUserData(dataToSend.username, data.sessionKey, data.nickname);
                that.loadUserData();
            }).done();
        },

        logout: function () {
            var that = this;

            return requester.httpGet(this.userUrl + 'logout/' + this.sessionKey)
            .then(function () {
                that.deleteUserData();
            }).fail(function (error) {
                console.log(error);
            });
            
        },
        loadUserData: function(){
            this.username = localStorage.getItem('username');
            this.sessionKey = localStorage.getItem('sessionKey');
            this.nickname = localStorage.getItem('nickname');
        },
        saveUserData: function(username, sessionKey, nickname){
            if (username) {
                localStorage.setItem('username', username);
            }

            localStorage.setItem('sessionKey', sessionKey);

            if (nickname) {
                localStorage.setItem('nickname', nickname);
            } 
        },
        deleteUserData: function () {
            localStorage.removeItem('username');
            localStorage.removeItem('sessionKey');
            localStorage.removeItem('nickname');
            this.username = 'undefined';
            this.sessionKey = 'undefined';
            this.nickname = 'undefined'
        }

    });

    return {
        get: function (url) {
            return new MainPersister(url);
        }
    }
    
});