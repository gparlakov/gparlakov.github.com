﻿/// <reference path="class.js" />
/// <reference path="jquery-2.0.2.js" />
/// <reference path="uiGenerator.js" />

var BullsAndCows = BullsAndCows || {};

BullsAndCows.uiController = (function () {
    var uiController = Class.create({
        loginForm: {},
        registerForm: {},
        gameScreen: {},
        init: function (selector) {
            this.parentElement = $(selector);
            this.uiGenerator = BullsAndCows.uiGenerator;                   
        },        
        clearFormsAndGameScreen: function () {
            if (this.registerForm.remove) {
                this.registerForm.remove();
            }
            if (this.loginForm.remove) {
                this.loginForm.remove();
            }    
            if(this.gameScreen.remove){
                this.gameScreen.remove();
            }
        },
        loadLoginForm: function () {
            this.clearFormsAndGameScreen();
            this.loginForm = $(BullsAndCows.uiGenerator.getLoginForm()).appendTo(this.parentElement);            
        },
        loadRegisterForm: function () {
            this.clearFormsAndGameScreen();
            this.registerForm = $(BullsAndCows.uiGenerator.getRegisterForm()).appendTo(this.parentElement);
        },
        loadGameScreen: function (player, openGames, activeGames) {
            this.clearFormsAndGameScreen();
            var player = $("<p class='username'>" + player + "</p>");
            var gameScreen = this.uiGenerator.getGameScreen();
            this.gameScreen = $(gameScreen).appendTo(this.parentElement);
            this.gameScreen.append(player);            
        },
        loadErrorMessage: function (error) {            
            if (error && error.responseText) {
                alert(error.responseText);
            }
            else {
                alert("Unexpected error.")
            }
        },        
    });
    
    return {
        get: function (selector) {
            return new uiController(selector);
        }
    }
}());