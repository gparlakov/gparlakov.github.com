﻿/// <reference path="jquery-2.0.2.js" />
/// <reference path="q.js" />

var BullsAndCows = BullsAndCows || {};
var requester = (function () {
    var deferred = Q.defer();

    var makeRequest = function (url, type, data) {
        $.ajax({
            url: url,
            type: type,
            data: (data)?JSON.stringify(data):'undefined',
            contentType: "application/json",
            success: function (data) {
                deferred.resolve(data);
            },
            error: function (errorData) {
                deferred.reject(errorData);
            }
        });

        return deferred.promise;
    };

    var httpGet = function (url) {
        return makeRequest(url, "get");
    };
    
    var httpPost = function (url, data) {
        return makeRequest(url, "post", data);
    }

    return {
        httpGet: httpGet,
        httpPost: httpPost
    }
}());