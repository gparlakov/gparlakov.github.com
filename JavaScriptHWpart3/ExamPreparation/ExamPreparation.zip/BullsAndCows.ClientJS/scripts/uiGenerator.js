﻿var BullsAndCows = BullsAndCows || {};

BullsAndCows.uiGenerator = (function () {
    var getLoginForm = function () {
        return '<form id="forms">                                        ' +
        '    <fieldset id="login-form">                           ' +
        '        <legend> Login Form</legend>                     ' +
        '                                                         ' +
        '        <label for="login-username">Username:</label>    ' +
        '        <input type="text" id ="login-username"/>        ' +
        '                                                         ' +
        '        <label for="login-password">Passoword:</label>    ' +
        '        <input type="text" id ="login-password"/>        ' +
        '                                                         ' +
        '        <button id="login-button">Login</button>         ' +
        '    </fieldset>                                          ' +
        '</form>';
    };

    var getRegisterForm = function () {
        return '    <fieldset id="register-form">                        ' +
        '        <legend>Register Form</legend>                   ' +
        '        <label for="register-username">Username:</label> ' +
        '        <input type="text" id ="register-username"/>     ' +
        '                                                         ' +
        '        <label for="register-nickname">Nickname:</label> ' +
        '        <input type="text" id ="register-nickname"/>     ' +
        '                                                         ' +
        '        <label for="register-password">Password:</label> ' +
        '        <input type="text" id ="register-password"/>     ' +
        '                                                         ' +
        '        <button id="register-button">Register</button>   ' +
        '                                                         ' +
        '    </fieldset>                                          ';

    };

    var getGameScreen = function () {
        return '<div id="game-screen">   ' +
        '    <h2>Game Screen</h2> ' +
        '    <div id="activeGames"></div>' +
        '<div id="openGames"></div> ' +
        '</div>                   ';
    };

    return {
        getLoginForm: getLoginForm,
        getRegisterForm: getRegisterForm,
        getGameScreen: getGameScreen
    }
}());