﻿/// <reference path="jquery-2.0.2.js" />
/// <reference path="q.js" />
/// <reference path="requestMaker.js" />

var BullsAndCows = BullsAndCows || {};

BullsAndCows.controller = Class.create({
    persister: {},
    uiController:{},
    init: function (persister, uiController) {
        this.persister = persister;
        this.uiController = uiController;
    },
    initGame: function () {
        if (this.persister.userIsLoggedIn()) {
            this.uiController.loadGameScreen();
        }
        else {
            this.uiController.loadLoginForm(this.persister.userPersister.nickname);
        }

        this.initEvents();
    },
    initEvents: function () {
        var that = this;
        var parent = this.uiController.parentElement;
        var registerForm = this.uiController.registerForm;
        

        var prevent = function (event) {
            event.preventDefault();
            event.stopPropagation();
        }

        parent.on("click", "#login-button", function (event) {             
            var loginForm = that.uiController.loginForm;
            var name = loginForm.find('#login-username').val();
            var password = loginForm.find("#login-password").val();

            that.persister.userPersister.login(name, password)
                .then(function () {
                    var username = localStorage.getItem("username");
                    that.uiController.clearFormsAndGameScreen();
                    that.uiController.loadGameScreen(username);
                })
                .fail(function (error) {
                    that.uiController.loadErrorMessage(error);
                }).done();

            prevent(event);
        });

        parent.on('click', '#toggle-forms', function (event) {
            that.uiController.clearFormsAndGameScreen();

            var button = $(this);

            if (button.hasClass('login')) {
                button.html('Login Form');
                that.uiController.loadRegisterForm();
            }
            else {
                button.html('Register Form');
                that.uiController.loadLoginForm();
            }

            button.toggleClass('login').toggleClass('register');

            prevent(event);
        })

        parent.on('click', '#logout-button', function (event) {               
            that.persister.userPersister.logout()
                .then(function () {
                    that.uiController.loadLoginForm();                    
                }).fail(function (error) {
                    that.uiController.loadErrorMessage(error);
                }).done();

            prevent(event);
        })
    }
});      
    


//$(window).ready(function () {

//});