﻿/// <reference path="uiController.js" />
/// <reference path="persisters.js" />
/// <reference path="bullsCowsController.js" />
/// <reference path="jquery-2.0.2.js" />

$(function () {

    var persister = BullsAndCows.persister().get("http://localhost:40643/api/");

    var uiController = BullsAndCows.uiController.get("#bulls-and-cows");

    var gameController = new BullsAndCows.controller(persister, uiController);

    //gameController.initEvents();
    gameController.initGame();


    //gameController.persister.userPersister.login("gosho", "123456")
    //    .then(function () {
    //        gameController.uiController.text = "success";
    //    }).fail(function (error) {
    //        console.log(error)
    //    });

});